from wsknn.fit_transform import fit
from wsknn.predict import predict
from wsknn.model.wsknn import WSKNN


__version__ = '0.1.5'
