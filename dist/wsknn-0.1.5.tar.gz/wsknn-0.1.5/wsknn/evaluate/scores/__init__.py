from wsknn.evaluate.scores.scores import mrr_func, precision_func, recall_func
