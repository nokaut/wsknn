from wsknn.evaluate.metrics import score_model, get_recall, get_precision, get_mean_reciprocal_rank
